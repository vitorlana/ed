#ifndef __NAVE_CLASS__
#define __NAVE_CLASS__

struct Nave
{
    int _ident;
    Nave *prox = NULL;
    Nave *ante = NULL;
};


#endif
